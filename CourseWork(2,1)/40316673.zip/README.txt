Author: Edwin John Thorpe 40316673
Date of Modification: 23/02/18
Purpose of Program: To output all unique words and the amount
of times they occur with a total word count from a file. 

---------------------Running the Program----------------------

To run program open Developer Command Prompt for VS 2017
-
Set location using "cd" to 40316673 file
-
Run the make file using "nmake"
-
That will compile and run the program for both test files-
with and without caps and output to unique files

--------------------------------------------------------------

Microsoft (R) C/C++ Optimizing Compiler Version 19.12.25835 for x86
Copyright (C) Microsoft Corporation.  All rights reserved.